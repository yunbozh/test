#ifndef PLATFORM_H
#define PLATFORM_H
/**
 * ƽ̨���
 */
#if defined(_WIN32) || defined(__WIN32__) || defined(WIN32)
#define SYSTEM_WIN // win ƽ̨
#else
#define SYSTEM_LINUX // linux ƽ̨
#endif


#endif


