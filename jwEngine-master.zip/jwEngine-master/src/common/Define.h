#ifndef _DEFINE_H_
#define _DEFINE_H_

#include "Platform.h"

#ifdef SYSTEM_WIN
	#include <Windows.h>
#endif

#define TRINITY_BIGENDIAN 1



#endif